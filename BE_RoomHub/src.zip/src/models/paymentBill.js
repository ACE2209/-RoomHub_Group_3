import mongoose from "mongoose";

const BillSchema = new mongoose.Schema({
  oldNumber: {
    type: Number,
    required: true,
  },
  newNumber: {
    type: Number,
    required: true,
  },
  quantityConsumed: {
    type: Number,
    required: true,
  },
  totalAmount: {
    type: Number,
    required: true,
  },
});

const paymentBillSchema = new mongoose.Schema(
  {
    roomId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Room",
      required: true,
    },
    paymentAmount: {
      type: Number,
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ["Pending", "Overdue", "Done", "Cancel", "Paid", "Failed"],
      default: "Pending",
    },
    additionalFee: [
      {
        feeName: {
          type: String,
        },
        feeAmount: {
          type: Number,
          default: 0,
        },
      },
    ],
    electricalBill: BillSchema,
    waterBill: BillSchema,
    month: {
      type: Number,
    },
    year: {
      type: Number,
    },
    dueDate: Date,
    gracePeriodEnd: Date,
    overdueAt: Date,
    closedAt: Date,
  },
  {
    timestamps: {
      createdAt: true,
      updatedAt: false,
    },
  }
);

paymentBillSchema.index(
  { roomId: 1, month: 1, year: 1 },
  {
    unique: true,
    partialFilterExpression: {
      roomId: { $exists: true },
      month: { $exists: true },
      year: { $exists: true },
    },
  }
);

const PaymentBill = mongoose.model("PaymentBill", paymentBillSchema);

export default PaymentBill;
