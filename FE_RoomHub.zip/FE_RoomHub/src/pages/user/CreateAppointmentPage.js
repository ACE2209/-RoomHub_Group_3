import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { createAppointment } from "../../api/appointment";

export default function CreateAppointmentPage() {
  const { roomId } = useParams();
  const navigate = useNavigate();

  const [appointmentDate, setAppointmentDate] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!roomId) {
      alert("Room is required");
      return;
    }

    if (!appointmentDate) {
      alert("Appointment date and time is required");
      return;
    }

    if (note.length > 500) {
      alert("Note cannot exceed 500 characters");
      return;
    }

    const selectedDate = new Date(appointmentDate);
    const oneHourLater = new Date();
    oneHourLater.setHours(oneHourLater.getHours() + 1);

    if (selectedDate < oneHourLater) {
      alert("Appointment must be scheduled at least 1 hour in advance");
      return;
    }

    try {
      setLoading(true);

      const res = await createAppointment({
        roomId,
        appointmentDate,
        note,
      });

      if (res?.success) {
        alert("Appointment created successfully");
        navigate("/appointments");
      } else {
        alert(res?.message || "Create appointment failed");
      }
    } catch (error) {
      console.error("Create appointment failed:", error);
      alert(error.message || "Create appointment failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <button style={backBtnStyle} onClick={() => navigate(-1)}>
          ← Back
        </button>

        <h2 style={titleStyle}>Create a room viewing request</h2>

        <form onSubmit={handleSubmit}>
          <div style={formGroupStyle}>
            <label style={labelStyle}>Room</label>
            <input
              value={roomId}
              disabled
              style={inputStyle}
            />
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle}>Date & Time *</label>
            <input
              type="datetime-local"
              value={appointmentDate}
              onChange={(e) => setAppointmentDate(e.target.value)}
              style={inputStyle}
            />
          </div>

          <div style={formGroupStyle}>
            <label style={labelStyle}>
              Note ({note.length}/500)
            </label>
            <textarea
              value={note}
              maxLength={500}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Enter note optional"
              style={textareaStyle}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              ...submitBtnStyle,
              opacity: loading ? 0.6 : 1,
              cursor: loading ? "not-allowed" : "pointer",
            }}
          >
            {loading ? "Submitting..." : "Submit request"}
          </button>
        </form>
      </div>
    </div>
  );
}

const pageStyle = {
  minHeight: "100vh",
  background: "#f8fafc",
  padding: "40px",
  display: "flex",
  justifyContent: "center",
};

const cardStyle = {
  width: "520px",
  background: "white",
  borderRadius: "14px",
  padding: "28px",
  boxShadow: "0 4px 18px rgba(0,0,0,0.08)",
};

const backBtnStyle = {
  background: "transparent",
  border: "none",
  color: "#344054",
  fontSize: "16px",
  cursor: "pointer",
  marginBottom: "18px",
};

const titleStyle = {
  color: "#27364a",
  fontWeight: "700",
  marginBottom: "26px",
};

const formGroupStyle = {
  marginBottom: "18px",
};

const labelStyle = {
  display: "block",
  marginBottom: "8px",
  color: "#344054",
  fontWeight: "600",
};

const inputStyle = {
  width: "100%",
  height: "44px",
  border: "1px solid #d0d5dd",
  borderRadius: "8px",
  padding: "0 12px",
  fontSize: "15px",
  boxSizing: "border-box",
};

const textareaStyle = {
  width: "100%",
  height: "120px",
  border: "1px solid #d0d5dd",
  borderRadius: "8px",
  padding: "12px",
  fontSize: "15px",
  resize: "none",
  boxSizing: "border-box",
};

const submitBtnStyle = {
  width: "100%",
  background: "#14b8a6",
  color: "white",
  border: "none",
  borderRadius: "8px",
  padding: "14px",
  fontWeight: "700",
  fontSize: "16px",
};