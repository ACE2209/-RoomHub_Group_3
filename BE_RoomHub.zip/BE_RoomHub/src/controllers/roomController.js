import mongoose from "mongoose";
import Room from "../models/room.js";

class roomController {
  async getRoomsByBoardingHouse(req, res) {
    try {
      const { boardingHouseId } = req.params;

      if (!mongoose.Types.ObjectId.isValid(boardingHouseId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid boardingHouseId",
        });
      }

      const rooms = await Room.find({
        boardingHouseId,
        isAvailable: true,
      })
        .select("_id roomNumber isAvailable roomTypeId")
        .populate("roomTypeId", "name price peopleNumber")
        .sort({ roomNumber: 1 })
        .lean();

      return res.status(200).json({
        success: true,
        data: rooms,
      });
    } catch (error) {
      console.error("Error fetching rooms by boarding house:", error);

      return res.status(500).json({
        success: false,
        message: "Server error",
        error: error.message,
      });
    }
  }
}

export default new roomController();